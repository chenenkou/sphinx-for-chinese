#define SPH_SVN_TAG "rel099"
#define SPH_SVN_REV 1785
#define SPH_SVN_REVSTR "1785"
#define SPH_SVN_TAGREV "r1785"
#define SPHINX_TAG "-rc2"
